import { useEffect, useState } from 'react'
import Paragraph from './components/Paragraph'
import Image from './components/Image'
import axios from 'axios';
import './index.css';

function App() {
  const [imageList, setImageList] = useState([])

  useEffect(() => {
    getData();
  }, [])

  function getData() {
    axios
      .get('https://picsum.photos/v2/list?limit=12')
      .then((response) => {
        console.log( response )
        console.log(response.data)
        setImageList(response.data);
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
      });
  }

  if (!imageList.length) return <p>Carregando...</p>

  return (
    <>
    <header></header>
    <main></main>
    <main>
      <div className='general'>
        {imageList.map((image) => {
          return (
            <div className='generals' key={image.id}>
              <Image width='400px' height='600px' url={image.download_url} />
              <Paragraph tamanho='16px'>Name: {image.author}</Paragraph>
            </div>
          );
        })}
      </div>
    </main>
    </>
  );
}

export default App

