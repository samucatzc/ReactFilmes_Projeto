function Image(props) {
    return (
        <img 
            src={props.url} 
            style={{
                width: props.width,
                height: props.height,
                borderRadius: '5px',
                gridTemplateColumns: 'repeat(3, 1fr)' // Corrigi o nome da propriedade
            }}
        />
    );
}

export default Image;
