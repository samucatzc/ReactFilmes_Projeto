import PropTypes from 'prop-types';

function Paragraph(props) {
    return (
        <p
            style={{
                color: props.cor,
                fontSize: props.tamanho,
                fontWeight: 'bold'
            }}
        >
            {props.children}
        </p>
    );
}

Paragraph.propTypes = {
    children: PropTypes.node, // Alterei de PropTypes.any para PropTypes.node
    tamanho: PropTypes.string,
    cor: PropTypes.string
};

export default Paragraph;
